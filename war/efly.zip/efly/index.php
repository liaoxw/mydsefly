<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>国内酒店</title>
<link rel="stylesheet" type="text/css" href="css/cssyui.css">
<link rel="stylesheet" type="text/css" href="css/css.css">
<script type="text/javascript" src="scripts/jquery.min.js"></script>
</head>
<body class="yui3-g">
<div class="yui3-u-1">
	<div>国内订房搜索</div>
	<div>
		所在城市：<select onchange="selectCity(this.value);" id="city_id"> 
			<option value='TP1' selected >台北市</option> 
            <option value='TP2' >台北縣 </option> 
        	<option value='KEE' >基隆 </option> 
        	<option value='TA1' >桃園 </option> 
        	<option value='HSZ' >新竹 </option> 
        	<option value='MI1' >苗栗 </option> 
        	<option value='TXG' >台中 </option> 
        	<option value='ZH1' >彰化 </option> 
        	<option value='NA0' >南投 </option> 
        	<option value='YU1' >雲林 </option> 
        	<option value='CYI' >嘉義 </option> 
        	<option value='TNN' >台南 </option> 
        	<option value='KHH' >高雄 </option> 
        	<option value='PIF' >屏東 </option> 
        	<option value='YI0' >宜蘭 </option> 
        	<option value='HUN' >花蓮 </option> 
        	<option value='TTT' >台東 </option> 
        	<option value='MZG' >澎湖 </option> 
        	<option value='KNH' >金門 </option> 
        	<option value='MFK' >馬祖 </option></select>
		旅遊區：<select id="views" name="view_id" onchange="selectView(this.value);"><option value="">不限</option></select>
	</div>
	<div>
		飯店型態：<select id="hotelType" name="hotel_type" onchange="selectType(this.value);"><option value="">不限</option></select>
		房型：<select>
			<option value="0" selected>不限</option>         
          <option value="1">單人房</option>  
          <option value="2">雙人房</option>  
          <option value="3">三人房</option>  
          <option value="4">四人房以上</option>
          </select> 
	</div>
	<div>
		飯店名稱：<select id="hotelList" name="hotel_list"><option value="">不限</option></select>
	</div>
	<div>
		入住日期：<input type="text" name="check_in"/> ~ 退房日期：<input type="text" name="check_out" />
	</div>
	<div><button type="button" onclick="search();">搜索</button></div>
</div>
<div class="yui3-u-1" id="result">
	
</div>
<script type="text/javascript">
var hotelType=[],hotelList;
function selectCity(city_id){
	//取得区列表
	$.getJSON("api.php?model=2&action=5&city_id="+city_id,function(json){
		$('#views').empty();
		$('#views').append('<option value="">不限</option>');
		for(var a in json){
			$('#views').append('<option value="'+json[a].id+'">'+json[a].name+'</option>');
		}
	});
	//取得酒店列表
	$.getJSON("api.php?model=6&action=5&city_id="+city_id,function(json){
		hotelList = json;
		$('#hotelList').empty();
		$('#hotelList').append('<option value="">不限</option>');
		$('#hotelType').empty();
		$('#hotelType').append('<option value="">不限</option>');
		var type = [];
		for(var i in json){
			type[json[i].typeId] = 1;
			$('#hotelList').append('<option value="'+json[i].hotelId+'">'+json[i].name+'</option>');
		}
		for(var i in type){
			$('#hotelType').append('<option value="'+i+'">'+hotelType[i]+'</option>');
		}
	});
}

function selectView(view_id){
	//取得酒店列表
	$.getJSON("api.php?model=6&action=5&view_id="+view_id,function(json){
		hotelList = json;
		$('#hotelList').empty();
		$('#hotelList').append('<option value="">不限</option>');
		$('#hotelType').empty();
		$('#hotelType').append('<option value="">不限</option>');
		var type = [];
		for(var i in json){
			type[json[i].typeId] = 1;
			$('#hotelList').append('<option value="'+json[i].hotelId+'">'+json[i].name+'</option>');
		}
		for(var i in type){
			$('#hotelType').append('<option value="'+i+'">'+hotelType[i]+'</option>');
		}
	});
}

function selectType(type_id){
	$('#hotelList').empty();
	$('#hotelList').append('<option value="">不限</option>');
	for(var i in hotelList){
		if(hotelList[i].typeId == type_id){
			$('#hotelList').append('<option value="'+hotelList[i].hotelId+'">'+hotelList[i].name+'</option>');
		}
	}
}

function search(){
	var view_id = null;
	if($('#views').val() != ''){
		var view_id = $('#views').val();
	}
	alert(view_id);
	//$('#result').empty();
	//$('#result').append("正在载入中！");
	var url = "search.php?check_in=&check_out&hotel_id=";
	$('#hotelList option').each(function(){
		url+=$(this).val()+",";
	});
	//alert(url);
//	alert($('#hotelList').options);
	$('#result').load(url,function(){
	});
}

function init(){
	$.getJSON("api.php?model=6&action=1",function(json){
		for(var i in json){
			hotelType[json[i].id] = json[i].name;
		}
		selectCity('TP1');
	});
	
}
init();

</script>
</body>
</html>