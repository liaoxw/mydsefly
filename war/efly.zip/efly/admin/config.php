<?php
ini_set("display_errors",'On');
ini_set('error_reporting', E_ALL | E_STRICT);
define("APIURL","http://localhost:8888/efly");
//define("DB_HOST","127.0.0.1");
//define("DB_USERNAME","root");
//define("DB_PASSWORD","");
//define("DB_NAME","efly");

function getPDO(){
	$pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=efly','root', '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
	return $pdo;
}

function getData($model,$params){
	$content = getJSON($model, $params);
	if(!$content){
		return false;
	}else{
		return json_decode($content);
	}
	
}

function getJSON($model,$params){
	$p = "";
	if(is_array($params)){
		foreach($params as $key=>$val){
			$p .="&".$key."=".$val;
		}
	}
	$url = APIURL."?model=".$model . $p;
	$content = file_get_contents($url);
	return $content;
}


class MODEL{
	const NONE = "NONE";
	const CITY = "CITY";
	const VIEW = "VIEW";
	const HOTEL_INFO = "HOTEL_INFO";
	const HOTEL_IMAGE = "HOTEL_IMAGE";
	const HOTEL_ROOM_STATUS = "HOTEL_ROOM_STATUS";
	const HOTEL_ROOM_INFO = "HOTEL_ROOM_INFO";
}