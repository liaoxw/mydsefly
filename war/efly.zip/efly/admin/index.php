<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>管理后台</title>
<link rel="stylesheet" type="text/css" href="css/cssyui.css">
<link rel="stylesheet" type="text/css" href="css/css.css">
<script type="text/javascript" src="scripts/jquery.min.js"></script>

</head>
<body class="yui3-skin-sam">
<div id="hd"> 管理后台 </div>
<div class="yui3-g" id="bd">
	<div class="yui3-u-1-6">
		<div class="content" id="side">
			<ul>
				<li><a href="javascript:hotel.load();">酒店管理</a></li>
				<li><a href="#">城市区域管理</a></li>
				<li><a href="#">参数配置管理</a></li>
				<li><a href="#">订单管理</a></li>
			</ul>
		</div>
	</div>
	<div class="yui3-u-5-6">
		<div class="content" style="margin-left:10px;" id="main">
			正在载入内容！
		</div>
	</div>
</div>
<div id="footer">
	Footer;
</div>

<script type="text/javascript" src="scripts/index.js" ></script>

<script type="text/javascript">
hotel.load();
</script>
</body>
</html>