<?php
//phpinfo();
ini_set("display_errors",'On');
ini_set('error_reporting', E_ALL | E_STRICT);

//define("APIURL","http://localhost:8090/");
//class ParamsModel{
//	const NONE = 0;
//	const CITY = 1;
//	const VIEW = 2;
//	const HOTEL = 3;
//}
//
//function GetHotelList (){
//	$url = APIURL."?model=".ParamsModel::CITY;
//	$content = file_get_contents("http://localhost:8090/?model=3&city_id=cyi");
//	if($content){
//		//echo $content;
//		$data = json_decode($content);
//		var_dump($data);
//	}else{
//		echo $url . " :: false";
//	}
//}
$pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=efly','root', '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
$rs = $pdo->query("SELECT * FROM efly_hotel LIMIT 10");
while($row = $rs->fetch()){
	print_r($row);
}