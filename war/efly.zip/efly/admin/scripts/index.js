var hotel = {
	load:function(){
			$("#main").load("hotel/list.php");
		},
	info:{
		load:function(id){
			$("#main").load("hotel/info.php?action=read&id="+id);
		},
		crawl:function(id){
			$("#main").load("hotel/info.php?action=crawl&id="+id);
		}
	},
	image:{
		load:function(id){
			$("#main").load("hotel/image.php?action=list&id="+id);
		},
		crawl:function(id){
			$("#main").load("hotel/image.php?action=crawl&id="+id);
		}
	},
	room:{
		load:function(id){
			$("#main").load("hotel/room.php?action=list&id="+id);
		},
		crawl:function(id){
			$("#main").load("hotel/room.php?action=crawl&id="+id);
		}
	},
	area:{
		load:function(id){
			$("#main").load("hotel/area.php?action=read&id="+id);
		},
		update:function(id){
			$("#main").load("hotel/area.php?action=update&id="+id);
		}
	}
};

var city ={
		
};

