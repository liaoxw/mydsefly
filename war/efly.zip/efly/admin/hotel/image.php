<?php
include_once '../config.php';
$id = $_GET['id'];
$action = $_GET['action'];

if($action == "list"){
	$rs = getPDO()->query('SELECT * FROM efly_hotel_image WHERE hotel_id = "'.$id.'"');
?>
<div class="nav">酒店信息图片</div>
<div class="main">
	<table class="table">
		<thead>
			<tr>
				<th colspan="2">酒店图片</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			while($row = $rs->fetch()){
			?>
			<tr>
				<td><?php echo $row['image_id'];?></td>
				<td><img src="<?php echo $row['source_url'];?>" /></td>
			</tr>
			<?php } ?>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="2">
					<button onclick="hotel.image.crawl('<?php echo $id;?>')" >重新采集</button>
				</td>
			</tr>
		</tfoot>
	</table>
</div>
<?php 
}else if($action == "delete"){
	echo "删除图片";
}else if($action == "crawl"){
	$json = getData(MODEL::HOTEL_IMAGE,array("hotel_id"=>$id));
	var_dump($json);
	echo '<div class="nav">酒店图片采集信息</div><div class="main">';
	echo '<button onclick="hotel.image.load(\''.$id.'\');">采集成功，重新载入</button>';
	echo '</div></div>';
}
?>