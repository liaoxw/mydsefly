<?php 
include_once '../config.php';
//$json = getData(MODEL::HOTEL,ACTION::LISTS);
$pdo = getPDO();
$rs = $pdo->query("SELECT h.hotel_id,i.name,h.city_id,h.view_id,h.type_id FROM efly_hotel AS h LEFT JOIN efly_hotel_info as i ON h.hotel_id = i.hotel_id LIMIT 20");

?>

<div class="nav">酒店管理</div>
<div class="main">
	<div>
		<table class="table">
			<thead>
				<tr>
					<th width="120">ID</th>
					<th>名称</th>
					<th width="60">简介</th>
					<th width="60">图片</th>
					<th width="60">房间</th>
					<th width="60">所在区</th>
					<th width="60">操作</th>
				</tr>
			</thead>
			<tbody>
			<?php 
				while($row = $rs->fetch()){ ?>
				<tr>
					<td><?php echo $row['hotel_id'];?></td>
					<td><?php echo $row['name']; ?></td>
					<td><a href="javascript:hotel.info.load('<?php echo $row['hotel_id'];?>')">编辑</a></td>
					<td><a href="javascript:hotel.image.load('<?php echo $row['hotel_id'];?>')">查看</a></td>
					<td><a href="javascript:hotel.room.load('<?php echo $row['hotel_id'];?>')">查看</a></td>
					<td><a href="javascript:hotel.area.load('<?php echo $row['hotel_id'];?>')">查看</a></td>
					<td><a href="javascript:hotel.info.load('<?php echo $row['hotel_id'];?>')">删除</a></td>
				</tr>
			<?php } ?>
			</tbody>
		</table>
	</div>				
	<div id="pager">
		<span>上一页</span>    <span>下一页</span>
	</div>
</div>