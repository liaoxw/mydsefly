<?php
include_once '../config.php';
$id = $_GET['id'];
$action = $_GET['action'];
switch($action){
	case "list":
		$rs = getPDO()->query('SELECT * FROM efly_hotel_room WHERE hotel_id = "'.$id.'"');
		?>
		<div class="nav">酒店客房信息</div>
		<div class="main">
			<table class="table">
				<thead>
					<tr>
						<th>ID</th>
						<th>名称</th>
						<th>简述</th>
						<th>价格</th>
						<th>操作</th>
					</tr>
				</thead>
				<tbody>
				<?php
				$i=0;
					while($row = $rs->fetch()){ 
				?>
					<tr>
						<td><?php echo $i++;?></td>
						<td><?php echo $row['name'];?></td>
						<td><?php echo $row['summary'];?></td>
						<td><?php echo $row['price']; echo " ".$row['price_x'];?></td>
						<td><a href="#">查看状态</a></td>
					</tr>
				<?php } ?>
				</tbody>
				<tfoot>
					<tr>
						<td colspan="5">
							<button type="button" onclick="hotel.room.crawl('<?php echo $id;?>')"> 重新采集 </button>
						</td>
					</tr>
				</tfoot>
			</table>
		</div>
		<?php 
		break;
	case "crawl":
		$json = getData(MODEL::HOTEL_ROOM_INFO, array("hotel_id"=>$id));
		var_dump($json);
		echo '<div class="nav">酒店客房信息采集</div><div class="main">';
		echo '<button onclick="hotel.room.load(\''.$id.'\');">采集成功，重新载入</button>';
		echo '</div></div>'; 
		break;
}
?>