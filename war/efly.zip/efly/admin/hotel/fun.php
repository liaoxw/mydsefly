<?php
include_once '../config.php';
$action = $_GET['action'];
switch($action){
	case 'crawl':
	 	$json = getData(MODEL::HOTEL,ACTION::CRAWL,array("id"=>$_GET['id']));
	 	var_dump($json);
	 	break;
}