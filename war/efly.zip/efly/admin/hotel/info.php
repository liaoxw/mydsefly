<?php 
include_once '../config.php';
$id = $_GET['id'];
$action = $_GET['action'];
if($action == "read"){
	$rs = getPDO()->query('SELECT * FROM efly_hotel_info WHERE hotel_id = "'.$id.'"');
	$row = $rs->fetch();
?>
<div class="nav">编辑酒店信息</div>
<div class="main">
	<div id="hotelInfo">
		<form action="#">
			<table class="table">
				<thead>
					<tr>
						<th colspan="2"><?php echo $row['name'];?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td width="100">名称：</td>
						<td><input class="txt" type="text" value="<?php echo $row['name'];?>" /></td>
					</tr>
					<tr>
						<td width="100">地址：</td>
						<td><input class="txt" type="text" value="<?php echo $row['address'];?>" /></td>
					</tr>
					<tr>
						<td width="100">电话：</td>
						<td><input class="txt" type="text" value="<?php echo $row['telphone'];?>" /></td>
					</tr>
					<tr>
						<td width="100">登記入住時間：</td>
						<td><input class="txt" type="text" value="<?php echo $row['check_in_time'];?>" /></td>
					</tr>
					<tr>
						<td width="100">辦理退房時間：</td>
						<td><input  class="txt" type="text" value="<?php echo $row['check_out_time'];?>" /></td>
					</tr>
					<tr>
						<td width="100">接送服務：</td>
						<td><input class="txt" type="text" value="<?php echo $row['send_pick_service'];?>" /></td>
					</tr>
					<tr>
						<td width="100">飯店網址：</td>
						<td><input class="txt" type="text" value="<?php echo $row['website'];?>" /></td>
					</tr>
					<tr>
						<td width="100">客房設施：</td>
						<td><textarea class="mtxt"><?php echo $row['room_facility'];?></textarea></td>
					</tr>
					<tr>
						<td width="100">餐飲設施：</td>
						<td><textarea class="mtxt"><?php echo $row['dining_facility'];?></textarea></td>
					</tr>
					<tr>
						<td width="100">休閒設施：</td>
						<td><textarea class="mtxt"><?php echo $row['leisure_facility'];?></textarea></td>
					</tr>
					<tr>
						<td width="100">交通資訊：</td>
						<td><textarea class="mtxt"><?php echo $row['transportation_info'];?></textarea></td>
					</tr>
					<tr>	
						<td width="100">取消規定：</td>
						<td><textarea class="mtxt"><?php echo $row['sendcancel_policy'];?></textarea></td>
					</tr>
					<tr>
						<td width="100">相關說明(注意事項)：</td>
						<td><textarea class="mtxt"><?php echo $row['related_explanation'];?></textarea></td>
					</tr>
				</tbody>
				<tfoot>
					<tr>
						<td style="text-align: center" colspan="2">
							<button type="button"> 保存 </button>
							<button type="button" onclick="hotel.info.crawl('<?php echo $id;?>')"> 重新采集 </button>
							<button> 取消修改并返回 </button>
						</td>
					</tr>
				</tfoot>
			</table>
		</form>
	</div>
</div>
<?php  
} 
else if($action == "update"){
	
}else if($action == "delete"){
	
}else if($action == "crawl"){
	$json = getData(MODEL::HOTEL_INFO,array("hotel_id"=>$_GET['id']));
	var_dump($json);
	echo '<div class="nav">酒店信息采集</div><div class="main">';
	echo '<button onclick="hotel.info.load(\''.$id.'\');">采集成功，重新载入</button>';
	echo '</div></div>';
}
?>