<?php
include_once '../config.php';
$id = $_GET['id'];
$action = $_GET['action'];
switch ($action){
	case "read":
		echo "read";
		break;
	case "update":
		break;
}