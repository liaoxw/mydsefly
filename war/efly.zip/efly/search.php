<?php
include_once 'admin/config.php';

$city_id = $_GET['city_id'];
$view_id = $_GET['view_id'];
$hotel_type = $_GET['hotel_type'];
$room_limit = $_GET['room_limit'];
$hotel_id = $_GET['hotel_id'];
$check_in = $_GET['check_in'];
$check_out = $_GET['check_out'];
echo $hotel_id;
?>
<table>
		<thead>
			<tr>
				<th>序</th>
				<th>照片</th>
				<th>飯店名稱</th>
				<th>特色</th>
				<th>價格</th>
				<th>訂購</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="6">next </td>
			</tr>
		</tfoot>
	</table>