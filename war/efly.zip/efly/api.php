<?php
include_once 'admin/config.php';
$model = $_GET['model'];
$action = $_GET['action'];
switch($model){
	case MODEL::CITY:
		$json = getJSON($model, $action,null);
		break;
	case MODEL::VIEW:
		$city_id = $_GET['city_id'];
		echo $content = getJSON($model, $action, array("city_id"=>$city_id));
		break;
	case MODEL::HOTEL_TYPE:
		$city_id = $_GET['city_id'];
		$view_id = $_GET['view_id'];
		if($view_id){
			echo getJSON($model, $action, array('view_id'=>$view_id));
		}else{
			echo getJSON($model, $action, array('city_id'=>$city_id));
		}
		break;
}